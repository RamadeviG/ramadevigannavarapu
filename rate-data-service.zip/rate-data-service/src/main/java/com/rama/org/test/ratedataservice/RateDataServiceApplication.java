package com.rama.org.test.ratedataservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RateDataServiceApplication {

	public static void main(String[] args) {
		SpringApplication.run(RateDataServiceApplication.class, args);
	}

}
